'use strict';

module.exports = {
  env: 'production',
  debug: false
};
